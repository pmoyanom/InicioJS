class Move {
    constructor(name, damage) {
        this.name = name;
        this.damage = damage;
    }
}

module.exports = Move; // Asegúrate de que esta línea esté presente
