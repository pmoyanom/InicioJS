const Types = {
    FIRE: 'Fuego',
    WATER: 'Agua',
    GRASS: 'Planta',
    ELECTRIC: 'Eléctrico',
    NORMAL: 'Normal',
};

module.exports = Types